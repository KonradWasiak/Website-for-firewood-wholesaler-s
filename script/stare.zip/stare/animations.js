$(window).on('load', function() {
    $(".loader").fadeOut(1000);
});


$(window).on('beforeunload', function(){
  $(window).scrollTop(0);
});

$(function()
{
	if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) 
	{
		$('.animation-fade-in').addClass('fade-in-on-load');
	}
    
	$('.fade-in-on-load').each(function()
	{
        $(this).animate({'opacity':'1'},750)
	})
	
    $(window).scroll( function(){
        $('.animation-fade-in').each( function(i){
            var bottom_of_object = $(this).position().top + $(this).outerHeight();
            var bottom_of_window = $(window).scrollTop() + $(window).height();
            if( bottom_of_window+200 > bottom_of_object){
                $(this).animate({'opacity':'1'},500);
            }
        }); 
    });
});